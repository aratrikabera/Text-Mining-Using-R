library(tm)
library(ggplot2)
library(SnowballC)
library(wordcloud)

#Create corpus
docs <- Corpus(DirSource("C:/Users/Somnath/Desktop/Android development/Data Analytics/textm2/corp_t"))
writeLines(as.character(docs[[1]]))
writeLines(as.character(docs[[15]]))
writeLines(as.character(docs[[30]]))
myStopWords <- c("can", "say", "howev", "also", "will",
                 "well", "said","even","often")

docs <- tm_map(docs, removePunctuation)
#Create toSpace content transformation to replace certain
#punctuations such as hyphens etc with space between 
#immediate two words
toSpace <- content_transformer(function(x, pattern) {return
  (gsub(pattern," ",x))})
docs <- tm_map(docs, toSpace, " — ")
docs <- tm_map(docs, toSpace, "—")
docs <- tm_map(docs, toSpace, "'")
docs <- tm_map(docs, toSpace, ",")
docs <- tm_map(docs, toSpace, " -")
docs <- tm_map(docs, toSpace, " — ")

docs <- tm_map(docs,content_transformer(tolower))

docs <- tm_map(docs,removeNumbers)


docs <- tm_map(docs, removeWords, stopwords("english"))
docs <- tm_map(docs, stripWhitespace)
docs <- tm_map(docs,stemDocument)

docs <- tm_map(docs, content_transformer(gsub), 
               pattern = "written", replacement = "write")
docs <- tm_map(docs, content_transformer(gsub), 
               pattern = "wrote", replacement = "write")
docs <- tm_map(docs, content_transformer(gsub), 
               pattern = "hillaryclintoncom", replacement = "hillary")
docs <- tm_map(docs, content_transformer(gsub), 
               pattern = "iwillvotecom", replacement = "vote")
docs <- tm_map(docs, content_transformer(gsub), 
               pattern = "better", replacement = "good")
docs <- tm_map(docs, content_transformer(gsub), 
               pattern = "great", replacement = "good")

myStopWords <- c("can", "say", "howev", "also", "will",
                 "well", "said","even","often", "us", 
                 "let", "for", "a", "now", "use", "go",
                 "told", "wouldnt", "yet", "just", "applause",
                 "back", "talk", "take", "much", "know", "that",
                 "realli","thing", "much", "famili", "give", "thank",
                 "like", "tell", "want", "time", "good", "dont", "applaus")
docs <- tm_map(docs, removeWords, myStopWords)

writeLines(as.character(docs[[15]]))

dtm <- DocumentTermMatrix(docs)
dtm
#dimensions are 30 rows and 4383 columns
#87% of this is 0
inspect(dtm[1:2,1000:1005])

#To get the frequency of each term in the corpus (columns)
freq <- colSums(as.matrix(dtm))
freq
length(freq) #4379
#Descending order of term count
ord <- order(freq,decreasing=TRUE)
#inspect most frequently occuring terms
freq[head(ord)]

#inspect least frequently occuring terms
freq[tail(ord)]
dtmr <-Documentdtmr <-DocumentTermMatrix(docs, control=list(wordLengths=c(4, 20),
                                             bounds = list(global = c(3,27))))
freqr <- colSums(as.matrix(dtmr))
length(freqr) #1578
#create sort order (asc)
ordr <- order(freqr,decreasing=TRUE)
#inspect most frequently occurring terms
freqr[head(ordr)]
#inspect least frequently occurring terms
freqr[tail(ordr)]

findFreqTerms(dtmr, lowfreq = 80)

findAssocs(dtmr,"donald",0.7)
findAssocs(dtmr,"hillary",0.8)
findAssocs(dtmr,"romney",0.6)
findAssocs(dtmr,"obama",0.6)
findAssocs(dtmr,"mitt",0.6)

#Plotting
wf=data.frame(term=names(freqr),occurrences=freqr)
p <- ggplot(subset(wf, freqr>100), aes(term, occurrences))
p <- p + geom_bar(stat="identity")
p <- p + theme(axis.text.x=element_text(angle=45, hjust=1))
p

set.seed(45)
wordcloud(names(freqr),freqr,min.freq=80,colors=brewer.pal(6,"Dark2"))